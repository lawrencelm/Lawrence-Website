------------------
Professional One Page Resume
Format: PSD
font: Arial
designed by Rochmanu Yahya | yahya12.deviantart.com
------------------

Thank you for downloading this file

This freebie has been release for you by ibrandstudio.com

you can edit the text inside psd file and mix color in custome color folder.

You can freely use it for both your private and commercial projects under one condition - put a back link to http://ibrandstudio.com

Please link to the article in which this freebie was released if you would like to spread the word.

-----------------
Anyway if you love this design, we offer design services to customize this template, or make a new template specially for you, please contact us for details.
-----------------

IBS team,
IBrandStudio.com

---contact---
ibrandstudio@gmail.com
