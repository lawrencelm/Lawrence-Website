------------------
product: resume template
Format: PSD
font: Arial
designed by Rochmanu Yahya | yahya12.deviantart.com
------------------

Thank you for downloading this file

This freebie has been release for you by ibrandstudio.com

you can edit the text inside psd file and mix color in custome color folder.

You can freely use it for both your private and commercial projects under one condition - put a back link to www.ibrandstudio.com

Please link to the article in which this freebie was released if you would like to spread the word.


IBS team,
IBrandStudio.com

---contact---
ibrandstudio@gmail.com